# Prac 2 
Working with Delays, RTCs and I2C on the STM32 Discovery

## Folder Contents
#### EEE3096S_2022_Prac_2_Delays_and_I2C_Student_Version
STMCubeIDE project containing some implementation.

## Running the Prac
Copy EEE3096S_2022_Prac_2_Delays_and_I2C_Student_Version directory into your STMCubeIDE workspace and import.
Read the prac handout on Vula for more details
